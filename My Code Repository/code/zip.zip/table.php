<?php
    $_POST['p']='Code';
    $_POST['r']='2';
    include("../banner.php");
?>
<STYLE>
	SPAN {
	    PADDING-LEFT: 1VW;
	}
</STYLE>
<TABLE STYLE="LINE-HEIGHT:8VH;FONT:2VW 'Monaco', 'Menlo', 'Ubuntu Mono', 'Consolas', 'source-code-pro', monospace;">
    <TBODY>
        <TR>
            <TD><SPAN><font color="red">R</font>adios </SPAN></TD>
            <TD><SPAN><font color="red">M</font>ake </SPAN></TD>
            <TD><SPAN><font color="red">I</font>nterferince </SPAN></TD>
            <TD><SPAN><font color="red">V</font>ery </SPAN></TD>
            <TD><SPAN><font color="red">U</font>ncomferble </SPAN></TD>
            <TD><SPAN><font color="red">E</font>xpet </SPAN></TD>
            <TD><SPAN><font color="red">G</font>ospel</SPAN></TD>
        </TR>
        <TR>
            <TD><SPAN>A</SPAN></TD>
            <TD><SPAN>I</SPAN></TD>
            <TD><SPAN>N</SPAN></TD>
            <TD><SPAN>I</SPAN></TD>
            <TD><SPAN>L</SPAN></TD>
            <TD><SPAN>-</SPAN></TD>
            <TD><SPAN>A</SPAN></TD>
        </TR>
        <TR>
            <TD><SPAN>D</SPAN></TD>
            <TD><SPAN>C</SPAN></TD>
            <TD><SPAN>F</SPAN></TD>
            <TD><SPAN>S</SPAN></TD>
            <TD><SPAN>T</SPAN></TD>
            <TD><SPAN>R</SPAN></TD>
            <TD><SPAN>M</SPAN></TD>
        </TR>
        <TR>
            <TD><SPAN>I</SPAN></TD>
            <TD><SPAN>R</SPAN></TD>
            <TD><SPAN>R</SPAN></TD>
            <TD><SPAN>I</SPAN></TD>
            <TD><SPAN>T</SPAN></TD>
            <TD><SPAN>A</SPAN></TD>
            <TD><SPAN>M</SPAN></TD>
        </TR>
        <TR>
            <TD><SPAN>O</SPAN></TD>
            <TD><SPAN>O</SPAN></TD>
            <TD><SPAN>A</SPAN></TD>
            <TD><SPAN>B</SPAN></TD>
            <TD><SPAN>A</SPAN></TD>
            <TD><SPAN>Y</SPAN></TD>
            <TD><SPAN>A</SPAN></TD>
        </TR>
        <TR>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN>W</SPAN></TD>
            <TD><SPAN>R</SPAN></TD>
            <TD><SPAN>L</SPAN></TD>
            <TD><SPAN>V</SPAN></TD>
            <TD><SPAN>S</SPAN></TD>
            <TD><SPAN> </SPAN></TD>
        </TR>
        <TR>
            <TD><SPAN>W</SPAN></TD>
            <TD><SPAN>A</SPAN></TD>
            <TD><SPAN>E</SPAN></TD>
            <TD><SPAN>E</SPAN></TD>
            <TD><SPAN>I</SPAN></TD>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN>R</SPAN></TD>
        </TR>
        <TR>
            <TD><SPAN>A</SPAN></TD>
            <TD><SPAN>V</SPAN></TD>
            <TD><SPAN>D</SPAN></TD>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN>O</SPAN></TD>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN>A</SPAN></TD>
        </TR>
        <TR>
            <TD><SPAN>V</SPAN></TD>
            <TD><SPAN>E</SPAN></TD>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN>L</SPAN></TD>
            <TD><SPAN>L</SPAN></TD>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN>Y</SPAN></TD>
        </TR>
        <TR>
            <TD><SPAN>E</SPAN></TD>
            <TD><SPAN>S</SPAN></TD>
            <TD><SPAN>W</SPAN></TD>
            <TD><SPAN>I</SPAN></TD>
            <TD><SPAN>E</SPAN></TD>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN>S</SPAN></TD>
        </TR>
        <TR>
            <TD><SPAN>S</SPAN></TD>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN>A</SPAN></TD>
            <TD><SPAN>G</SPAN></TD>
            <TD><SPAN>T</SPAN></TD>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN> </SPAN></TD>
        </TR>
        <TR>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN>V</SPAN></TD>
            <TD><SPAN>H</SPAN></TD>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN> </SPAN></TD>
        </TR>
        <TR>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN>E</SPAN></TD>
            <TD><SPAN>T</SPAN></TD>
            <TD><SPAN>W</SPAN></TD>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN> </SPAN></TD>
        </TR>
        <TR>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN>S</SPAN></TD>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN>A</SPAN></TD>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN> </SPAN></TD>
        </TR>
        <TR>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN>R</SPAN></TD>
            <TD><SPAN>V</SPAN></TD>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN> </SPAN></TD>
        </TR>
        <TR>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN>A</SPAN></TD>
            <TD><SPAN>E</SPAN></TD>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN> </SPAN></TD>
        </TR>
        <TR>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN>Y</SPAN></TD>
            <TD><SPAN>S</SPAN></TD>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN> </SPAN></TD>
        </TR>
        <TR>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN>S</SPAN></TD>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN> </SPAN></TD>
            <TD><SPAN> </SPAN></TD>
        </TR>
    </tBODY>
</TABLE>
<?php echo(file_get_contents("../footer.php"));?>