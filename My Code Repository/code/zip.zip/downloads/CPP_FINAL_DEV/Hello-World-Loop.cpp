#include <iostream>
using namespace std;
int main () {   
    // do loop statement
    for(int a=0;a<10;a ++){
        cout << "Hello World!" << endl;
    }
    //says loop has ended
    cout << "The end has been reached." << endl;
    return 0;
}