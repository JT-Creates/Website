        </div>
        <footer>
            Proudly Served by Apache Web Server. <a href="Https://theelectronichandbook.tech">theelectronichandbook</a>
        </footer>
    </body>
</html>