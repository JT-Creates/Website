<?php
    $_GET['p']='ERROR 404';
    $_POST['r']='1';
    include("./banner.php");
?>
<h1><i><u>Typo</u></i>: the wrong url could not be found.</h1>
<?php include("./footer.php");?>
  <noscript> <meta http-equiv=refresh content="0; URL=/enable-javascript.html" /> </noscript>