<!doctype html>
<html><head><link rel="stylesheet" type="text/css" href="./code/style.css"></head><body>
<div id="page">
<h1>Electronics Handbook</h1>
<ul class="navbar">
  <li id="ni"><a href="./">Home</a></li>
  <li id="ni"><a href="./parts/">Components</a></li>
  <li id="ni"><a href="https://klove.com/listen/player/">Klove radio</a></li>
  <li id="ni"><a href="./events.html">Events</a></li>
</ul>
<br>
<strong><b><h1>Sorry we are down</h1></b></strong>
<?php include("./footer.php");?>