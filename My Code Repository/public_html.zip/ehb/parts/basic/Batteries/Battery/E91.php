<!-- APPENDED - 04-06-21 : 03.06.29.607735 -->
<?php $date="04-06-21 : 03.06.29.607735";
$ynam="Energizer";
$nam="AA";
$pn="E91";
$mf="";
$cat="Battery";
$sum="1.5 volt ENERGIZER AA battery";
$inf="Classification: Alkaline Chemical System: Zinc-Manganese Dioxide (Zn/MnO2 ) Designation: ANSI-15A, IEC-LR6 Nominal Voltage: 1.5 volts Nominal IR: 150 to 300 milliohms (fresh) Operating Temp: -18°C to 55°C (0°F to 130°F) Typical Weight: 23.0 grams (0.8 oz.) Typical Volume: 8.1 cubic centimeters (0.5 cubic inch) Jacket: Plastic Label Shelf Life: 10 years at 21°C Terminal: Flat Contact";
$link="https://data.energizer.com/pdf";
?>
