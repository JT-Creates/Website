<!-- APPENDED - 04-06-21 : 03.06.21.299444 -->
<?php $date="04-06-21 : 03.06.21.299444";
$ynam="JT Stevens";
$nam="Duracell Optimum AA";
$pn="OP1500";
$mf="Duracell";
$cat="Battery";
$sum="Duracell Optimum AA battery.";
$inf="Duracell Optimum AA batteries are capable of longer lifetime then other batteries. ";
$link="https://www.duracell.com/wp-content/uploads/2016/03/OP1500_US_OP1.pdf";
?>
