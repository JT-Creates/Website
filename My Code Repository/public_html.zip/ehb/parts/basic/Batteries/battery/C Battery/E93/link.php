<?php $link="https://data.energizer.com/pdfs/e93.pdf";?>
<?php $link="https://data.energizer.com/pdfs/e93.pdf";?>
