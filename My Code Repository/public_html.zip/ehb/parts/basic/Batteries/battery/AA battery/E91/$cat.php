<?php $cat="battery";?>
