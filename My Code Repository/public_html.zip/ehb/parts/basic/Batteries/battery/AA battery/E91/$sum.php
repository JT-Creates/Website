<?php $sum="1.5 volt ENERGIZER AA battery";?>
