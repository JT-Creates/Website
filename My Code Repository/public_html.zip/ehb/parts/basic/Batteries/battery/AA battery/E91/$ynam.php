<?php $ynam="jt";?>
