<?php $nam="AA battery";?>
