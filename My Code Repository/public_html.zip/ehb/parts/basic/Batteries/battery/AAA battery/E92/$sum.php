<?php $sum="1.5 volt ENERGIZER AAA battery";?>
