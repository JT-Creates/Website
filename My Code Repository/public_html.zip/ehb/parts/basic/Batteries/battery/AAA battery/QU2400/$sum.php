<?php $sum="1.5 volt duracell AAA battery";?>
