<?php $nam="AAA battery";?>
