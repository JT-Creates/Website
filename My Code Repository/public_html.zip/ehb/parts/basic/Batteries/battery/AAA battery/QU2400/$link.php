<?php $link="https://d2ei442zrkqy2u.cloudfront.net/wp-content/uploads/2016/03/QU2400_US_UL1.pdf";?>
