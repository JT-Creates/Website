<!-- APPENDED - 04-06-21 : 03.06.42.620744 -->
<?php $date="04-06-21 : 03.06.42.620744";
$ynam="JT Stevens";
$nam="Energizer Max AAA";
$pn="E92";
$mf="Energizer";
$cat="Battery";
$sum="1.5 volt ENERGIZER AAA battery";
$inf="Classification: Alkaline Chemical System: Zinc-Manganese Dioxide (Zn/MnO2 ) Designation: ANSI-24A, IEC-LR03 Nominal Voltage: 1.5 volts Nominal IR: 150 to 300 milliohms (fresh) Operating Temp: -18°C to 55°C (0°F to 130°F) Typical Weight: 11.5 grams (0.4 oz.) Typical Volume: 3.8 cubic centimeters (0.2 cubic inch) Jacket: Plastic Label Shelf Life: 10 years at 21°C";
$link="https://data.energizer.com/pdfs/e92.pdf";
?>
<!-- APPENDED - 04-06-21 : 06.06.50.379813 -->
<?php $date="04-06-21 : 06.06.50.379813";
$ynam="JT Stevens";
$nam="Energizer AAA";
$pn="E92";
$mf="Energizer";
$cat="Battery";
$sum="1.5 volt ENERGIZER AAA battery";
$inf="Classification: Alkaline Chemical System: Zinc-Manganese Dioxide (Zn/MnO2 ) Designation: ANSI-24A, IEC-LR03 Nominal Voltage: 1.5 volts Nominal IR: 150 to 300 milliohms (fresh) Operating Temp: -18°C to 55°C (0°F to 130°F) Typical Weight: 11.5 grams (0.4 oz.) Typical Volume: 3.8 cubic centimeters (0.2 cubic inch) Jacket: Plastic Label Shelf Life: 10 years at 21°C";
$link="https://data.energizer.com/pdfs/e92.pdf";
?>
<!-- APPENDED - 04-06-21 : 07.06.23.839187 -->
<?php $date="04-06-21 : 07.06.23.839187";
$ynam="JT Stevens";
$nam="Energizer AAA";
$pn="E92";
$mf="Energizer";
$cat="Battery";
$sum="1.5 volt ENERGIZER AAA battery";
$inf="Classification: Alkaline Chemical System: Zinc-Manganese Dioxide (Zn/MnO2 ) Designation: ANSI-24A, IEC-LR03 Nominal Voltage: 1.5 volts Nominal IR: 150 to 300 milliohms (fresh) Operating Temp: -18°C to 55°C (0°F to 130°F) Typical Weight: 11.5 grams (0.4 oz.) Typical Volume: 3.8 cubic centimeters (0.2 cubic inch) Jacket: Plastic Label Shelf Life: 10 years at 21°C";
$link="https://data.energizer.com/pdfs/e92.pdf";
?>
