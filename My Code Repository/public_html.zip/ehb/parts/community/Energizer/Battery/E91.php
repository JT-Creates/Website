<!-- APPENDED - 04-06-21 : 03.06.50.885660 -->
<?php $date="04-06-21 : 03.06.50.885660";
$ynam="JT Stevens";
$nam="Energizer AA";
$pn="E91";
$mf="Energizer";
$cat="Battery";
$sum="1.5 volt ENERGIZER AA battery";
$inf="Classification: Alkaline Chemical System: Zinc-Manganese Dioxide (Zn/MnO2 ) Designation: ANSI-15A, IEC-LR6 Nominal Voltage: 1.5 volts Nominal IR: 150 to 300 milliohms (fresh) Operating Temp: -18°C to 55°C (0°F to 130°F) Typical Weight: 23.0 grams (0.8 oz.) Typical Volume: 8.1 cubic centimeters (0.5 cubic inch) Jacket: Plastic Label Shelf Life: 10 years at 21°C Terminal: Flat Contact";
$link="https://data.energizer.com/pdf";
?>
<!-- APPENDED - 04-06-21 : 06.06.44.319259 -->
<?php $date="04-06-21 : 06.06.44.319259";
$ynam="JT Stevens";
$nam="AA";
$pn="E91";
$mf="Energizer";
$cat="Battery";
$sum="1.5 volt ENERGIZER AA battery";
$inf="Classification: Alkaline Chemical System: Zinc-Manganese Dioxide (Zn/MnO2 ) Designation: ANSI-15A, IEC-LR6 Nominal Voltage: 1.5 volts Nominal IR: 150 to 300 milliohms (fresh) Operating Temp: -18°C to 55°C (0°F to 130°F) Typical Weight: 23.0 grams (0.8 oz.) Typical Volume: 8.1 cubic centimeters (0.5 cubic inch) Jacket: Plastic Label Shelf Life: 10 years at 21°C Terminal: Flat Contact";
$link="https://data.energizer.com/pdf";
?>
<!-- APPENDED - 04-06-21 : 06.06.18.053204 -->
<?php $date="04-06-21 : 06.06.18.053204";
$ynam="JT Stevens";
$nam="AA";
$pn="E91";
$mf="Energizer";
$cat="Battery";
$sum="1.5 volt ENERGIZER AA battery";
$inf="Classification: Alkaline Chemical System: Zinc-Manganese Dioxide (Zn/MnO2 ) Designation: ANSI-15A, IEC-LR6 Nominal Voltage: 1.5 volts Nominal IR: 150 to 300 milliohms (fresh) Operating Temp: -18°C to 55°C (0°F to 130°F) Typical Weight: 23.0 grams (0.8 oz.) Typical Volume: 8.1 cubic centimeters (0.5 cubic inch) Jacket: Plastic Label Shelf Life: 10 years at 21°C Terminal: Flat Contact";
$link="https://data.energizer.com/pdf";
?>
<!-- APPENDED - 04-06-21 : 06.06.49.947137 -->
<?php $date="04-06-21 : 06.06.49.947137";
$ynam="JT Stevens";
$nam="AA";
$pn="E91";
$mf="Energizer";
$cat="Battery";
$sum="1.5 volt ENERGIZER AA battery";
$inf="Classification: Alkaline Chemical System: Zinc-Manganese Dioxide (Zn/MnO2 ) Designation: ANSI-15A, IEC-LR6 Nominal Voltage: 1.5 volts Nominal IR: 150 to 300 milliohms (fresh) Operating Temp: -18°C to 55°C (0°F to 130°F) Typical Weight: 23.0 grams (0.8 oz.) Typical Volume: 8.1 cubic centimeters (0.5 cubic inch) Jacket: Plastic Label Shelf Life: 10 years at 21°C Terminal: Flat Contact";
$link="https://data.energizer.com/pdf";
?>
<!-- APPENDED - 04-06-21 : 06.06.08.829193 -->
<?php $date="04-06-21 : 06.06.08.829193";
$ynam="JT Stevens";
$nam="AA";
$pn="E91";
$mf="Energizer";
$cat="Battery";
$sum="1.5 volt ENERGIZER AA battery";
$inf="Classification: Alkaline Chemical System: Zinc-Manganese Dioxide (Zn/MnO2 ) Designation: ANSI-15A, IEC-LR6 Nominal Voltage: 1.5 volts Nominal IR: 150 to 300 milliohms (fresh) Operating Temp: -18°C to 55°C (0°F to 130°F) Typical Weight: 23.0 grams (0.8 oz.) Typical Volume: 8.1 cubic centimeters (0.5 cubic inch) Jacket: Plastic Label Shelf Life: 10 years at 21°C Terminal: Flat Contact";
$link="https://data.energizer.com/pdf";
?>
<!-- APPENDED - 04-06-21 : 06.06.14.857983 -->
<?php $date="04-06-21 : 06.06.14.857983";
$ynam="JT Stevens";
$nam="AA";
$pn="E91";
$mf="Energizer";
$cat="Battery";
$sum="1.5 volt ENERGIZER AA battery";
$inf="Classification: Alkaline Chemical System: Zinc-Manganese Dioxide (Zn/MnO2 ) Designation: ANSI-15A, IEC-LR6 Nominal Voltage: 1.5 volts Nominal IR: 150 to 300 milliohms (fresh) Operating Temp: -18°C to 55°C (0°F to 130°F) Typical Weight: 23.0 grams (0.8 oz.) Typical Volume: 8.1 cubic centimeters (0.5 cubic inch) Jacket: Plastic Label Shelf Life: 10 years at 21°C Terminal: Flat Contact";
$link="https://data.energizer.com/pdf";
?>
<!-- APPENDED - 04-06-21 : 06.06.08.903530 -->
<?php $date="04-06-21 : 06.06.08.903530";
$ynam="JT Stevens";
$nam="Energizer AA";
$pn="E91";
$mf="Energizer";
$cat="Battery";
$sum="1.5 volt ENERGIZER AA battery";
$inf="Classification: Alkaline Chemical System: Zinc-Manganese Dioxide (Zn/MnO2 ) Designation: ANSI-15A, IEC-LR6 Nominal Voltage: 1.5 volts Nominal IR: 150 to 300 milliohms (fresh) Operating Temp: -18°C to 55°C (0°F to 130°F) Typical Weight: 23.0 grams (0.8 oz.) Typical Volume: 8.1 cubic centimeters (0.5 cubic inch) Jacket: Plastic Label Shelf Life: 10 years at 21°C Terminal: Flat Contact";
$link="https://data.energizer.com/pdf";
?>
<!-- APPENDED - 04-06-21 : 07.06.22.860191 -->
<?php $date="04-06-21 : 07.06.22.860191";
$ynam="JT Stevens";
$nam="Energizer AA";
$pn="E91";
$mf="Energizer";
$cat="Battery";
$sum="1.5 volt ENERGIZER AA battery";
$inf="Classification: Alkaline Chemical System: Zinc-Manganese Dioxide (Zn/MnO2 ) Designation: ANSI-15A, IEC-LR6 Nominal Voltage: 1.5 volts Nominal IR: 150 to 300 milliohms (fresh) Operating Temp: -18°C to 55°C (0°F to 130°F) Typical Weight: 23.0 grams (0.8 oz.) Typical Volume: 8.1 cubic centimeters (0.5 cubic inch) Jacket: Plastic Label Shelf Life: 10 years at 21°C Terminal: Flat Contact";
$link="https://data.energizer.com/pdfs/e91.pdf";
?>
