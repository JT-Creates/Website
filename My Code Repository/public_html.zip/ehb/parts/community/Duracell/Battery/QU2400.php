<!-- APPENDED - 04-06-21 : 03.06.42.324833 -->
<?php $date="04-06-21 : 03.06.42.324833";
$ynam="JT Stevens";
$nam="Duracell Quantum AAA";
$pn="QU2400";
$mf="Duracell";
$cat="Battery";
$sum="1.5 volt ENERGIZER AAA battery";
$inf="Composition: Alkaline-Manganese Dioxide Battery Nominal voltage 1.5 V Impedance 114 m-ohm @ 1 kHz Typical weight 11 g (0.4 oz) Typicalvolume 3.5 cm3 (0.2 in3 ) Terminals Flat Storage temperature range 5ºCto 30ºC(41ºFto 86ºF) Operating temperature range -20ºCto 54ºC(-4ºFto 130ºF) Designation ANSI: 24A IEC: LR03";
$link="https://d2ei442zrkqy2u.cloudfront.net/wp-content/uploads/2016/03/QU2400_US_UL1.pdf";
?>
<!-- APPENDED - 04-06-21 : 06.06.12.310052 -->
<?php $date="04-06-21 : 06.06.12.310052";
$ynam="JT Stevens";
$nam="Duracell Quantum AAA:";
$pn="QU2400";
$mf="Duracell";
$cat="Battery";
$sum="1.5 volt ENERGIZER AAA battery";
$inf=" Alkaline-Manganese Dioxide Battery Nominal voltage 1.5 V Impedance 114 m-ohm @ 1 kHz Typical weight 11 g (0.4 oz) Typicalvolume 3.5 cm3 (0.2 in3 ) Terminals Flat Storage temperature range 5ºCto 30ºC(41ºFto 86ºF) Operating temperature range -20ºCto 54ºC(-4ºFto 130ºF) Designation ANSI: 24A IEC: LR03";
$link="https://d2ei442zrkqy2u.cloudfront.net/wp-content/uploads/2016/03/QU2400_US_UL1.pdf";
?>
<!-- APPENDED - 04-06-21 : 07.06.23.625903 -->
<?php $date="04-06-21 : 07.06.23.625903";
$ynam="JT Stevens";
$nam="Duracell Quantum AAA";
$pn="QU2400";
$mf="Duracell";
$cat="Battery";
$sum="1.5 volt Duracell Quantum AAA battery";
$inf="Composition: Alkaline-Manganese Dioxide Battery Nominal voltage 1.5 V Impedance 114 m-ohm @ 1 kHz Typical weight 11 g (0.4 oz) Typicalvolume 3.5 cm3 (0.2 in3 ) Terminals Flat Storage temperature range 5ºCto 30ºC(41ºFto 86ºF) Operating temperature range -20ºCto 54ºC(-4ºFto 130ºF) Designation ANSI: 24A IEC: LR03";
$link="https://d2ei442zrkqy2u.cloudfront.net/wp-content/uploads/2016/03/QU2400_US_UL1.pdf";
?>
