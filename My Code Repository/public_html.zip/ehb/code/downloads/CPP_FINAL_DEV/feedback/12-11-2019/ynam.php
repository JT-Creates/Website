<?php ynam="John";?>
