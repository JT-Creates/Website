<?php
    $_POST['p'] = 'Events';
    $_POST['r'] = '1';
    include("./banner.php");
    echo(file_get_contents("./footer.php"));
?>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>TBN Live</title>

  <script>
    window.ga=window.ga||function(){(ga.q=ga.q||[]).push(arguments)};ga.l=+new Date;
    ga('create', 'UA-19540423-6', 'auto');
    ga('send', 'pageview');
  </script>
  <script async="" src="https://www.google-analytics.com/analytics.js"></script>
  <script src="https://d2wy8f7a9ursnm.cloudfront.net/v4/bugsnag.min.js"></script>
  
<script src="//vpe-cdn.livestream.com/playerjs/0.x.x/player.js" async=""></script><link type="text/css" rel="stylesheet" href="//vpe-cdn.livestream.com/playerjs/0.x.x/player.css"><script src="//vpe-cdn.livestream.com/playerm/2.x.x/m.js" async=""></script><link type="text/css" rel="stylesheet" href="//vpe-cdn.livestream.com/playerm/2.x.x/m.css"></head>
<video class="video-view video-mse" src="blob:https://embed.vhx.tv/833cd789-6c89-46d3-a2e5-4a67501a8df7" controls=""></video>
<body>
    <!--
  <style>
    .player-container {
      bottom: 0;
      height: 100%;
      left: 0;
      position: fixed;
      right: 0;
      top: 0;
      width: 100%;
    }
</style>
-->
<div class="player-container" id="live-player-view"><div class="lsp-director"><div class="director-view"><div data-reactroot="" class="director-root"><!-- react-empty: 2 --></div></div><div class="core-view"><div data-reactroot="" class="lsp-video-player" data-component="root"><div class="dimension-layer"><div class="scroll-listener" style="inset: 0px; position: absolute; overflow: hidden; visibility: hidden; z-index: -1;"><div class="scroll-listener__expander" style="inset: 0px; position: absolute; overflow: hidden; visibility: hidden; z-index: -1;"><div class="expander__body" style="left: 0px; position: absolute; transition: all 0s ease 0s; top: 0px; width: 15360px; height: 8640px;"></div></div><div class="scroll-listener__shrinker" style="inset: 0px; position: absolute; overflow: hidden; visibility: hidden; z-index: -1;"><div class="shrinker__body" style="left: 0px; position: absolute; transition: all 0s ease 0s; top: 0px; width: 200%; height: 200%;"></div></div></div></div><div class="video-layer"><video class="video-view video-mse" src="blob:https://embed.vhx.tv/042b65a8-a128-4e36-bb5c-d300e4ec8c36"></video></div><div class="lsp-thumbnail lsp-invisible"><div class="lsp-thumbnail__view" style="background-image: url(&quot;https://img.new.livestream.com/events/00000000007e24a8/8a499b24-0acd-453f-9e27-32191b301f51_441924.jpg&quot;);"></div></div><div class="captions-compute-container"><div class="captions-renderer"><span class="captions-renderer__text" style="font-family: &quot;Arial Unicode Ms&quot;, &quot;PT Sans Caption&quot;, Arial, Helvetica, Roboto, Verdana, sans-serif; text-shadow: none; background-color: rgb(0, 0, 0); color: rgb(255, 255, 255); font-size: 1em;">CROWDED...<br> ♪ BUT DIDN'T YOU SAY CHURCH...<br></span></div></div><div class="captions-container lsp-hidden"><div class="captions-renderer captions-renderer--pinned"><div class="captions-renderer__window" style="background-color: rgba(0, 0, 0, 0);"><span class="captions-renderer__text" style="font-family: &quot;Arial Unicode Ms&quot;, &quot;PT Sans Caption&quot;, Arial, Helvetica, Roboto, Verdana, sans-serif; text-shadow: none; background-color: rgb(0, 0, 0); color: rgb(255, 255, 255); font-size: 1em;"><span><!-- react-text: 148 -->CROWDED...<!-- /react-text --><br></span><span><!-- react-text: 151 -->♪ BUT DIDN'T YOU SAY CHURCH...<!-- /react-text --><br></span></span></div></div></div><div class="ad-screen lsp-hidden"></div><div class="shade-layer shade-layer--top lsp-invisible"></div><div class="shade-layer shade-layer--bottom lsp-invisible"></div><div class="hit-overlay" data-component="hitOverlay"><div class="hit-overlay__play lsp-hidden"><div class="icon-sprite"><svg viewBox="0 0 78 78" version="1.1" xmlns="http://www.w3.org/2000/svg">
        <g id="overlay-play">
            <circle id="overlay-circle-background" fill-opacity="0.6" fill="#000000" cx="39" cy="39" r="34"></circle>
            <polygon id="overlay-icon-play" fill="#FAFAFA" points="55 39 29 52 29 26"></polygon>
        </g>
</svg></div></div></div><div class="control-bar lsp-invisible" data-component="controlBar"><div class="seek-bar"><div class="lsp-progress-bar"><div class="lsp-progress-bar__lines" style="border-left-width: 0px; border-right-width: 0px;"><div class="progress-line" style="width: 100%;"></div><div class="progress-line" style="width: 99.9631%; background-color: rgb(255, 255, 255);"></div></div></div><div class="seek-bar__highlight"><div class="seek-bar__progress-pointer lsp-hidden" style="transform: translateX(0px);"></div></div></div><div class="controls"><div class="layout"><div class="playback-control" data-component="playbackControl"><div class="play-holder lsp-hidden mouse-disabled"><div class="icon-sprite"><svg viewBox="0 0 30 30" version="1.1" xmlns="http://www.w3.org/2000/svg">
        <g id="icon-play" fill="#FFFFFF" fill-rule="evenodd">
            <path d="M10,8 L10,22 L21,15 L10,8 Z"></path>
        </g>
</svg></div></div><div class="pause-holder mouse-disabled"><div class="icon-sprite"><svg viewBox="0 0 30 30" version="1.1" xmlns="http://www.w3.org/2000/svg">
        <g id="icon-pause" fill="#FFFFFF" fill-rule="evenodd">
            <path d="M9,22 L13,22 L13,8 L9,8 L9,22 L9,22 Z M17,8 L17,22 L21,22 L21,8 L17,8 L17,8 Z"></path>
        </g>
</svg></div></div></div><div class="back-to-live-control" data-component="goToLive"><div class="back-to-live-control__icon mouse-disabled"><div class="icon-sprite"><svg viewBox="0 0 30 30" version="1.1" xmlns="http://www.w3.org/2000/svg">
        <g id="icon-go-to-live" fill-rule="evenodd" fill="#FFFFFF">
            <path d="M18,15.6363636 L18,22 L22,22 L22,8 L18,8 L18,14.3636364 L8,8 L8,22 L18,15.6363636 Z"></path>
        </g>
</svg></div></div></div><div class="volume-control" data-component="volumeControl"><div class="volume-icon mouse-disabled"><div class="volume-mute-holder lsp-hidden"><div class="icon-sprite"><svg viewBox="0 0 30 30" version="1.1" xmlns="http://www.w3.org/2000/svg">
        <g id="icon-volume-mute" fill="#FFFFFF" fill-rule="evenodd">
            <path d="M6,12 L6,18 L10,18 L15,23 L15,7 L10,12 L6,12 L6,12 Z"></path>
            <path d="M21,13.4 L18.6,11 L17,12.6 L19.4,15 L17,17.4 L18.6,19 L21,16.6 L23.4,19 L25,17.4 L22.6,15 L25,12.6 L23.4,11 L21,13.4 L21,13.4 Z"></path>
        </g>
</svg></div></div><div class="volume-semi-holder lsp-hidden"><div class="icon-sprite"><svg viewBox="0 0 30 30" version="1.1" xmlns="http://www.w3.org/2000/svg">
        <g id="icon-volume-semi" fill="#FFFFFF" fill-rule="evenodd">
            <path d="M6,12 L6,18 L10,18 L15,23 L15,7 L10,12 L6,12 L6,12 Z"></path>
            <path d="M17,20 C18.7659048,19.1584163 20,17.2364077 20,15 C20,12.7635923 18.7659048,10.8415837 17,10 L17,12.5609426 C17.6137494,13.1601199 18,14.0308592 18,15 C18,15.9691408 17.6137494,16.8398801 17,17.4390574 L17,20 Z"></path>
        </g>
</svg></div></div><div class="volume-full-holder"><div class="icon-sprite"><svg viewBox="0 0 30 30" version="1.1" xmlns="http://www.w3.org/2000/svg">
        <g id="icon-volume-full" fill="#FFFFFF" fill-rule="evenodd">
            <path d="M6,12 L6,18 L10,18 L15,23 L15,7 L10,12 L6,12 L6,12 Z"></path>
            <path d="M17,20 C18.7659048,19.1584163 20,17.2364077 20,15 C20,12.7635923 18.7659048,10.8415837 17,10 L17,12.5609426 C17.6137494,13.1601199 18,14.0308592 18,15 C18,15.9691408 17.6137494,16.8398801 17,17.4390574 L17,20 Z"></path>
            <path d="M17,24 C21.0079774,23.067433 24,19.392007 24,15 C24,10.607993 21.0079774,6.93256697 17,6 L17,8.11937964 C19.8914889,9.00179473 22,11.7484062 22,15 C22,18.2515938 19.8914889,20.9982053 17,21.8806204 L17,24 Z"></path>
        </g>
</svg></div></div></div></div><div class="volume-slider volume-slider--collapsed"><div class="lsp-progress-bar"><div class="lsp-progress-bar__lines" style="border-left-width: 4px; border-right-width: 4px;"><div class="progress-line" style="width: 100%;"></div><div class="progress-line" style="width: 50%; background-color: rgb(255, 255, 255);"></div></div></div></div><div class="expander"></div><!-- react-empty: 41 --><div class="captions-control" data-component="captionsControl"><div class="captions-control__on lsp-hidden mouse-disabled"><div class="icon-sprite"><svg viewBox="0 0 30 30" version="1.1" xmlns="http://www.w3.org/2000/svg">
        <g id="icon-captions-on" fill-rule="evenodd" fill="#FFFFFF">
            <path d="M4,8.99406028 C4,7.8927712 4.88967395,7 5.991155,7 L24.008845,7 C25.1085295,7 26,7.89451376 26,8.99406028 L26,21.0059397 C26,22.1072288 25.1103261,23 24.008845,23 L5.991155,23 C4.89147046,23 4,22.1054862 4,21.0059397 L4,8.99406028 Z M12,16 L14,16 L14,17.0018986 C14,18.1054196 13.1017394,19 12.0020869,19 L9.99791312,19 C8.89449617,19 8,18.1132936 8,17.0018986 L8,12.9981014 C8,11.8945804 8.89826062,11 9.99791312,11 L12.0020869,11 C13.1055038,11 14,11.8867064 14,12.9981014 L14,14 L12,14 L12,13 L10,13 L10,17 L12,17 L12,16 Z M20,16 L22,16 L22,17.0018986 C22,18.1054196 21.1017394,19 20.0020869,19 L17.9979131,19 C16.8944962,19 16,18.1132936 16,17.0018986 L16,12.9981014 C16,11.8945804 16.8982606,11 17.9979131,11 L20.0020869,11 C21.1055038,11 22,11.8867064 22,12.9981014 L22,14 L20,14 L20,13 L18,13 L18,17 L20,17 L20,16 Z"></path>
        </g>
</svg></div></div><div class="captions-control__off mouse-disabled"><div class="icon-sprite"><svg viewBox="0 0 30 30" version="1.1" xmlns="http://www.w3.org/2000/svg">
        <g id="icon-captions-off" fill-rule="evenodd" fill="#FFFFFF">
            <path d="M4,8.99406028 C4,7.8927712 4.88967395,7 5.991155,7 L24.008845,7 C25.1085295,7 26,7.89451376 26,8.99406028 L26,21.0059397 C26,22.1072288 25.1103261,23 24.008845,23 L5.991155,23 C4.89147046,23 4,22.1054862 4,21.0059397 L4,8.99406028 Z M6,10.0024733 C6,9.44882258 6.44494629,9 6.99339768,9 L23.0066023,9 C23.5552407,9 24,9.45576096 24,10.0024733 L24,19.9975267 C24,20.5511774 23.5550537,21 23.0066023,21 L6.99339768,21 C6.44475929,21 6,20.544239 6,19.9975267 L6,10.0024733 Z M12,16 L14,16 L14,17.0018986 C14,18.1054196 13.1017394,19 12.0020869,19 L9.99791312,19 C8.89449617,19 8,18.1132936 8,17.0018986 L8,12.9981014 C8,11.8945804 8.89826062,11 9.99791312,11 L12.0020869,11 C13.1055038,11 14,11.8867064 14,12.9981014 L14,14 L12,14 L12,13 L10,13 L10,17 L12,17 L12,16 Z M20,16 L22,16 L22,17.0018986 C22,18.1054196 21.1017394,19 20.0020869,19 L17.9979131,19 C16.8944962,19 16,18.1132936 16,17.0018986 L16,12.9981014 C16,11.8945804 16.8982606,11 17.9979131,11 L20.0020869,11 C21.1055038,11 22,11.8867064 22,12.9981014 L22,14 L20,14 L20,13 L18,13 L18,17 L20,17 L20,16 Z"></path>
        </g>
</svg></div></div></div><div class="settings-control" data-component="settingsControl"><div class="settings-holder mouse-disabled"><div class="icon-sprite"><svg viewBox="0 0 30 30" version="1.1" xmlns="http://www.w3.org/2000/svg"><defs><clipPath id="iconSettingsMask"><polygon points="24 6 6 6 6 24 24 24 24 19 15 19 15 11 24 11"></polygon></clipPath></defs><g id="iconSettings" fill="#FFFFFF" fill-rule="evenodd"><g id="iconSettingsCog" clip-path="url(#iconSettingsMask)"><path class="" d="M20.8581796,16.3027413 L23,15.6910769 L23,14.3092308 L20.8581179,13.6969801 C20.7049895,13.0054671 20.4325443,12.3588139 20.0634872,11.7797257 L21.1455385,9.83169231 L20.1683077,8.85446154 L18.2206451,9.93674904 C17.6413843,9.56752245 16.9945067,9.29496995 16.3027413,9.14182043 L15.6910769,7 L14.3089231,7 L13.6972587,9.14182043 C13.0209744,9.29154259 12.3875914,9.55538326 11.8183464,9.91210559 L9.84738462,8.83907692 L8.83907692,9.84769231 L9.91193316,11.8186216 C9.56325737,12.3750931 9.30333842,12.9928488 9.15201323,13.6520518 L7,14.2867692 L7,15.7132308 L9.15208323,16.3482531 C9.30344352,17.0074504 9.56339682,17.6251964 9.91210559,18.1816536 L8.83907692,20.1526154 L9.84738462,21.1612308 L11.8183664,20.087907 C12.3749042,20.4366632 12.992748,20.6966384 13.6520518,20.8479868 L14.2867692,23 L15.7132308,23 L16.3482531,20.8479168 C17.02274,20.6930458 17.6538305,20.4244859 18.2202743,20.0634872 L20.1683077,21.1455385 L21.1455385,20.1683077 L20.0634029,18.2204067 C20.4325523,17.6412069 20.7050511,16.9944118 20.8581796,16.3027413 L20.8581796,16.3027413 Z M15,19 C17.209139,19 19,17.209139 19,15 C19,12.790861 17.209139,11 15,11 C12.790861,11 11,12.790861 11,15 C11,17.209139 12.790861,19 15,19 L15,19 Z"></path></g><g id="iconSettings4k" class="lsp-hidden"><path id="letter-4" d="M16.5,12 L14,15.5 L14,16 L17,16 L17,18 L18,18 L18,12 L16.5,12 Z M17,13 L17,15 L15.5,15 L17,13 Z"></path><polygon id="letter-k" points="20 15 20 12 19 12 19 18 20 18 20 16 20.5 16 21.7999878 18 23 18 21.2857915 15.4286873 23 12.0018921 22 12.0018921 20.5 15"></polygon></g><g id="iconSettingsHd" class=""><polygon id="letter-h" points="16 15 16 12 15 12 15 18 16 18 16 16 18 16 18 18 19 18 19 12 18 12 18 15"></polygon><path id="letter-d" d="M21,17 L21,13 L22,13 C22.5522847,13 23,13.4433532 23,14.0093689 L23,15.9906311 C23,16.5480902 22.5561352,17 22,17 L21,17 Z M20,18 L20,12 L22,12 C23.1045695,12 24,12.8982606 24,13.9979131 L24,16.0020869 C24,17.1055038 23.1122704,18 22,18 L20,18 Z"></path></g></g></svg></div></div></div><div class="full-screen-control" data-component="fullScreenControl"><div class="full-screen-control__on mouse-disabled"><div class="icon-sprite"><svg viewBox="0 0 30 30" version="1.1" xmlns="http://www.w3.org/2000/svg">
        <g id="icon-fullscreen-on" fill="#FFFFFF" fill-rule="evenodd">
            <path d="M22,20 L19,20 L19,22 L23,22 L24,22 L24,17 L22,17 L22,20 L22,20 Z M7,8 L11,8 L11,10 L8,10 L8,13 L6,13 L6,8 L7,8 L7,8 Z M8,20 L8,17 L6,17 L6,21 L6,22 L11,22 L11,20 L8,20 L8,20 Z M24,9 L24,8 L19,8 L19,10 L22,10 L22,13 L24,13 L24,9 L24,9 Z" id="Rectangle-9"></path>
        </g>
</svg></div></div><div class="full-screen-control__off lsp-hidden mouse-disabled"><div class="icon-sprite"><svg viewBox="0 0 30 30" version="1.1" xmlns="http://www.w3.org/2000/svg">
        <g id="icon-fullscreen-off" fill="#FFFFFF" fill-rule="evenodd">
            <path d="M18,17 L22,17 L22,19 L19,19 L19,22 L17,22 L17,17 L18,17 L18,17 Z M11,11 L8,11 L8,13 L12,13 L13,13 L13,8 L11,8 L11,11 L11,11 Z M13,18 L13,22 L11,22 L11,19 L8,19 L8,17 L13,17 L13,18 L13,18 Z M19,11 L22,11 L22,13 L17,13 L17,12 L17,8 L19,8 L19,11 L19,11 Z" id="Rectangle-9"></path>
        </g>
</svg></div></div></div></div></div></div><div class="top-bar"><div class="top-bar__stream-trait"><div class="stream-trait"><div class="stream-trait__dvr"><div class="icon-sprite"><svg viewBox="0 0 35 16" version="1.1" xmlns="http://www.w3.org/2000/svg">
        <g id="icon-trait-dvr" fill-rule="evenodd">
            <rect id="background" fill="#4185BE" x="0" y="0" width="35" height="16" rx="2"></rect>
            <path d="M12.4228516,7.85107422 C12.4228516,9.14730466 12.0629919,10.1382615 11.3432617,10.8239746 C10.6235316,11.5096877 9.58692083,11.8525391 8.23339844,11.8525391 L6.03662109,11.8525391 L6.03662109,4 L8.46435547,4 C9.7140362,4 10.6861944,4.33658518 11.3808594,5.00976562 C12.0755243,5.68294607 12.4228516,6.63003947 12.4228516,7.85107422 L12.4228516,7.85107422 Z M11.0693359,7.89404297 C11.0693359,6.01415076 10.1902757,5.07421875 8.43212891,5.07421875 L7.3203125,5.07421875 L7.3203125,10.7729492 L8.23339844,10.7729492 C10.1240329,10.7729492 11.0693359,9.8133234 11.0693359,7.89404297 L11.0693359,7.89404297 Z M19.6760743,4 L21.0081055,4 L18.2581055,11.8525391 L16.9045899,11.8525391 L14.1653321,4 L15.4866211,4 L17.1248047,8.88232422 C17.2107427,9.11507278 17.3020503,9.41495585 17.3987305,9.78198242 C17.4954107,10.149009 17.5580728,10.4220369 17.5867188,10.6010742 C17.6332685,10.3289374 17.7048824,10.0138364 17.8015625,9.65576172 C17.8982427,9.29768701 17.977018,9.0327157 18.0378907,8.86083984 L19.6760743,4 Z M24.5284181,7.65234375 L25.4200196,7.65234375 C26.0180044,7.65234375 26.4512683,7.54134226 26.7198243,7.31933594 C26.9883803,7.09732962 27.1226563,6.76790583 27.1226563,6.33105469 C27.1226563,5.88704205 26.9776383,5.56836034 26.6875978,5.375 C26.3975572,5.18163966 25.9607126,5.08496094 25.3770509,5.08496094 L24.5284181,5.08496094 L24.5284181,7.65234375 Z M24.5284181,8.71582031 L24.5284181,11.8525391 L23.2447267,11.8525391 L23.2447267,4 L25.4629884,4 C26.4763398,4 27.2264951,4.18977675 27.7134767,4.56933594 C28.2004583,4.94889513 28.4439454,5.52180606 28.4439454,6.28808594 C28.4439454,7.26562989 27.935487,7.96207475 26.9185548,8.37744141 L29.1368165,11.8525391 L27.675879,11.8525391 L25.7959962,8.71582031 L24.5284181,8.71582031 Z" id="DVR" fill="#FFFFFF"></path>
        </g>
</svg></div></div></div></div><div class="top-bar__viewer-counter lsp-hidden"><div class="viewer-counter"><div class="viewer-counter__icon"><div class="icon-sprite"><svg viewBox="0 0 10 10" version="1.1" xmlns="http://www.w3.org/2000/svg">
        <g id="icon-person" fill="#FFFFFF" fill-rule="evenodd">
            <path d="M10,9.375 L10,9.79166667 C10,9.85339537 9.98071007,9.90354919 9.94212963,9.94212963 C9.90354919,9.98071007 9.85339537,10 9.79166667,10 L0.208333333,10 C0.14660463,10 0.0964508102,9.98071007 0.0578703704,9.94212963 C0.0192899306,9.90354919 0,9.85339537 0,9.79166667 L0,9.375 C0,8.9891956 0.129242535,8.66319578 0.387731481,8.39699074 C0.646220428,8.13078571 0.958717303,7.92245446 1.32523148,7.77199074 C1.69174566,7.62152703 2.05825434,7.47878154 2.42476852,7.34375 C2.7912827,7.20871846 3.10377957,7.03318009 3.36226852,6.81712963 C3.62075747,6.60107917 3.75,6.3425941 3.75,6.04166667 C3.71913565,6.01080231 3.67476881,5.96257749 3.61689815,5.89699074 C3.55902749,5.83140399 3.45871985,5.68480052 3.31597222,5.45717593 C3.17322459,5.22955133 3.04591105,4.9884272 2.93402778,4.7337963 C2.8221445,4.47916539 2.72183686,4.14930758 2.63310185,3.74421296 C2.54436684,3.33911834 2.5,2.92438484 2.5,2.5 C2.5,1.81326817 2.74498212,1.22492529 3.2349537,0.734953704 C3.72492529,0.244982118 4.31326817,0 5,0 C5.68673183,0 6.27507471,0.244982118 6.7650463,0.734953704 C7.25501788,1.22492529 7.5,1.81326817 7.5,2.5 C7.5,2.92438484 7.45756215,3.33718935 7.37268519,3.73842593 C7.28780822,4.1396625 7.18364259,4.4733783 7.06018519,4.73958333 C6.93672778,5.00578837 6.81327222,5.24112552 6.68981481,5.44560185 C6.56635741,5.65007818 6.46219178,5.80246863 6.37731481,5.90277778 L6.25,6.04166667 C6.25,6.3425941 6.37924253,6.60107917 6.63773148,6.81712963 C6.89622043,7.03318009 7.2087173,7.20871846 7.57523148,7.34375 C7.94174566,7.47878154 8.30825434,7.62152703 8.67476852,7.77199074 C9.0412827,7.92245446 9.35377957,8.13078571 9.61226852,8.39699074 C9.87075747,8.66319578 10,8.9891956 10,9.375 L10,9.375 Z" id="person"></path>
        </g>
</svg></div></div><div class="viewer-counter__count">0</div></div></div><div class="top-bar__title lsp-invisible">TBN Live - HD</div><div class="top-bar__external-components lsp-invisible" data-component="externalComponentContainer"></div></div><div class="sub-bar"><!-- react-empty: 59 --></div><div class="spinner-layer"><div class="spinner-layer__animation lsp-hidden"><div class="icon-sprite"><svg viewBox="0 0 68 68" version="1.1" xmlns="http://www.w3.org/2000/svg">
        <g id="spinner" fill="#FFFFFF" fill-rule="evenodd">
            <path d="M34,68 C52.7776815,68 68,52.7776815 68,34 C68,15.2223185 52.7776815,0 34,0 C15.2223185,0 0,15.2223185 0,34 C0,52.7776815 15.2223185,68 34,68 Z M34,65 C51.1208272,65 65,51.1208272 65,34 C65,16.8791728 51.1208272,3 34,3 C16.8791728,3 3,16.8791728 3,34 C3,51.1208272 16.8791728,65 34,65 Z" id="donut" fill-opacity="0.2"></path>
            <path d="M68,34 C68,15.2223185 52.7776815,0 34,0 L34,3 C51.1208272,3 65,16.8791728 65,34 L68,34 Z" id="segment"></path>
        </g>
</svg></div></div></div><div class="lsp-settings-window lsp-hidden" style="width: 120px;"><div class="lsp-settings-window__content" style="transform: translateX(0px);"><div class="lsp-settings-window__main"><div class="lsp-rendition-list"><div class="lsp-rendition-list__item button-mode"><div class="lsp-rendition-list__body"><div class="lsp-rendition-list__label">1080p</div><div class="lsp-rendition-list__rendition"><div class="icon-sprite"><svg viewBox="0 0 16 12" version="1.1" xmlns="http://www.w3.org/2000/svg">
        <g id="icon-rendition-hd" fill="#FFFFFF" fill-rule="evenodd">
            <path d="M0,2.0085302 C0,0.899249601 0.894513756,0 1.99406028,0 L14.0059397,0 C15.1072288,0 16,0.901950359 16,2.0085302 L16,9.9914698 C16,11.1007504 15.1054862,12 14.0059397,12 L1.99406028,12 C0.892771196,12 0,11.0980496 0,9.9914698 L0,2.0085302 Z M5,6 L5,3 L4,3 L4,9 L5,9 L5,7 L7,7 L7,9 L8,9 L8,3 L7,3 L7,6 L5,6 Z M10,8 L10,4 L11,4 C11.5522847,4 12,4.44335318 12,5.0093689 L12,6.9906311 C12,7.54809015 11.5561352,8 11,8 L10,8 Z M9,9 L9,3 L11,3 C12.1045695,3 13,3.89826062 13,4.99791312 L13,7.00208688 C13,8.10550383 12.1122704,9 11,9 L9,9 Z"></path>
        </g>
</svg></div></div></div></div><div class="lsp-rendition-list__item button-mode"><div class="lsp-rendition-list__body"><div class="lsp-rendition-list__label">720p</div><div class="lsp-rendition-list__rendition"><div class="icon-sprite"><svg viewBox="0 0 16 12" version="1.1" xmlns="http://www.w3.org/2000/svg">
        <g id="icon-rendition-hd" fill="#FFFFFF" fill-rule="evenodd">
            <path d="M0,2.0085302 C0,0.899249601 0.894513756,0 1.99406028,0 L14.0059397,0 C15.1072288,0 16,0.901950359 16,2.0085302 L16,9.9914698 C16,11.1007504 15.1054862,12 14.0059397,12 L1.99406028,12 C0.892771196,12 0,11.0980496 0,9.9914698 L0,2.0085302 Z M5,6 L5,3 L4,3 L4,9 L5,9 L5,7 L7,7 L7,9 L8,9 L8,3 L7,3 L7,6 L5,6 Z M10,8 L10,4 L11,4 C11.5522847,4 12,4.44335318 12,5.0093689 L12,6.9906311 C12,7.54809015 11.5561352,8 11,8 L10,8 Z M9,9 L9,3 L11,3 C12.1045695,3 13,3.89826062 13,4.99791312 L13,7.00208688 C13,8.10550383 12.1122704,9 11,9 L9,9 Z"></path>
        </g>
</svg></div></div></div></div><div class="lsp-rendition-list__item button-mode"><div class="lsp-rendition-list__body"><div class="lsp-rendition-list__label">540p</div></div></div><div class="lsp-rendition-list__item button-mode"><div class="lsp-rendition-list__body"><div class="lsp-rendition-list__label">360p</div></div></div><div class="lsp-rendition-list__item lsp-rendition-list__item--active"><div class="lsp-rendition-list__body"><div class="lsp-rendition-list__label lsp-rendition-list__label--active">Auto</div></div><div class="lsp-rendition-list__check"><div class="icon-sprite"><svg viewBox="0 0 12 12" version="1.1" xmlns="http://www.w3.org/2000/svg">
        <g id="icon-check" fill="#FFFFFF" fill-rule="evenodd">
            <polygon id="Shape" points="0 7.19230769 1.4 5.84615385 4 8.30769231 10.6 2 12 3.34615385 4 11"></polygon>
        </g>
</svg></div></div></div></div><div class="lsp-captions-options-item" data-component="captionsOptionsItem"><div class="lsp-divider lsp-divider--top"><div class="lsp-settings-menu-item"><div class="lsp-settings-menu-item__icon"><div class="lsp-captions-options-item__icon"><div class="icon-sprite"><svg viewBox="0 0 22 16" version="1.1" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" d="M0,1.99406028 C0,0.892771196 0.889673948,0 1.991155,0 L20.008845,0 C21.1085295,0 22,0.894513756 22,1.99406028 L22,14.0059397 C22,15.1072288 21.1103261,16 20.008845,16 L1.991155,16 C0.891470458,16 0,15.1054862 0,14.0059397 L0,1.99406028 Z M2,3.00247329 C2,2.44882258 2.44494629,2 2.99339768,2 L19.0066023,2 C19.5552407,2 20,2.45576096 20,3.00247329 L20,12.9975267 C20,13.5511774 19.5550537,14 19.0066023,14 L2.99339768,14 C2.44475929,14 2,13.544239 2,12.9975267 L2,3.00247329 Z M8,9 L10,9 L10,10.0018986 C10,11.1054196 9.10173938,12 8.00208688,12 L5.99791312,12 C4.89449617,12 4,11.1132936 4,10.0018986 L4,5.99810135 C4,4.89458045 4.89826062,4 5.99791312,4 L8.00208688,4 C9.10550383,4 10,4.88670635 10,5.99810135 L10,7 L8,7 L8,6 L6,6 L6,10 L8,10 L8,9 Z M16,9 L18,9 L18,10.0018986 C18,11.1054196 17.1017394,12 16.0020869,12 L13.9979131,12 C12.8944962,12 12,11.1132936 12,10.0018986 L12,5.99810135 C12,4.89458045 12.8982606,4 13.9979131,4 L16.0020869,4 C17.1055038,4 18,4.88670635 18,5.99810135 L18,7 L16,7 L16,6 L14,6 L14,10 L16,10 L16,9 Z" id="Combined-Shape"></path>
</svg></div></div></div><div class="lsp-settings-menu-item__label">Options</div><div class="lsp-settings-menu-item__arrow"><div class="lsp-settings-menu-item__arrow-icon"><div class="icon-sprite"><svg viewBox="0 0 6 8" version="1.1" xmlns="http://www.w3.org/2000/svg">
            <polygon id="arrow" fill-rule="evenodd" points="0 8 0 0 6 4"></polygon>
</svg></div></div></div></div></div></div></div></div></div><div class="lsp-tooltip lsp-hidden lsp-invisible" style="transform: translateX(10px) translateY(56px);"><div class="lsp-tooltip__text"></div></div><!-- react-empty: 70 --></div></div></div><div class="mjs-root-view"><div class="mjs-video-view"><video class="mjs-video-element" poster="https://vhx.imgix.net/tbn/assets/d43a9b92-0a4c-4898-bcff-d72b2f71522d-18d67a52.png"></video></div><div class="mjs-spinner-view" style="display: none;"><div class="mjs-spinner-view__donut"></div></div><div class="mjs-ad-view" style="display: none;"></div><div class="mjs-hit-view" style="display: block;"><div class="mjs-hit-view__play-icon"><div class="mjs-hit-view__arrow"></div></div></div></div></div>

<script src="https://vpe.cdn.vimeo.tv/ottwebanalytics/1.x.x/web-analytics.js"></script>
<script src="https://vpe.cdn.vimeo.tv/playerjsfallback/1.x.x/fallback.js"></script>
<script src="https://vpe.cdn.vimeo.tv/playerapiadapter/1.x.x/api-adapter.js"></script>
<script>
  var analytics = null;
  var apiAdapter = null;
  var analyticsConfig = {"site_id":39746,"user_email":"legobuildshq@gmail.com","user_id":27861798,"video_id":316857,"collection_id":"66646","is_live":1,"platform":"web","platform_version":null,"product_id":"32625","referrer":"https://www.tbn.org/"};
  var playerJsConfig = {
    accentColor: "#ffffff",
    accountId: 27460990,
    autoPlay: true,
    debug: false,
    eventId: 8266920,
    live: true,
    muxApiKey: "lrc6o7kvhc6npvqq2r5iks5u4",
    videoId: 221926855
  };
  // peerToPeerKey is an optional parameter, include only when key is present
  

  var playerMConfig = {
    autoPlay: false,
    debug: false,
    live: true,
    mediaUrl: "https://livestreamapis.com/v3/accounts/27460990/events/8266920/master.m3u8?token=1b78acccc2828168b27433b60a946982\u0026clientId=7051\u0026timestamp=1622862078443",
    muxApiKey: "lrc6o7kvhc6npvqq2r5iks5u4",
    thumbnailUrl: "https://vhx.imgix.net/tbn/assets/d43a9b92-0a4c-4898-bcff-d72b2f71522d-18d67a52.png"
  };

  function getPlayerImplementation(playerMeta) {
    switch (playerMeta.playerType) {
      case Fallback.Players.PLAYER_JS:
        return playerMeta.player.getCore();
      case Fallback.Players.PLAYER_M:
        return playerMeta.player;
      default:
        return null;
    }
  }

  function getPlayerAdapter(playerType) {
    switch (playerType) {
      case Fallback.Players.PLAYER_JS:
        return Analytics.Adapters.PlayerJs;
      case Fallback.Players.PLAYER_M:
        return Analytics.Adapters.PlayerM;
      default:
        return null;
    }
  }

  var fallback = new Fallback.init({
    debug            : false,
    playerEnvironment: "production",
    playerJsVersion  : "0.x.x",
    playerJsConfig   : playerJsConfig,
    playerMVersion   : "2.x.x",
    playerMConfig    : playerMConfig,
    targetView       : document.getElementsByClassName('player-container')[0],
  }, function (meta) {
    var AnalyticsAdapter = getPlayerAdapter(meta.playerType);
    var playerImplementation = getPlayerImplementation(meta);

    analytics = new Analytics.Video({
      superProperties: analyticsConfig,
      videoAdapter   : new AnalyticsAdapter(meta.player)
    });

    apiAdapter = new ApiAdapter.init({
      origin: "",
      adapter: new ApiAdapter.Adapters.Generic(playerImplementation)
    });
  });
</script>



</body>